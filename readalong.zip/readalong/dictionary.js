/* Author: Tyler Abrams
   Dictionary
*/

var dictionaryLoader = function(null,$pronaudio){
	var dictionaryClickHandler;
	var $thisWord;
	var $bookFrame=$('#passage-text');

	var $dictPopup = $('#dictPopup');
	var $dictClose = $('#dictClose');
	var $dictBody = $('#dictBody');
	var	$pronIcon = $('.pron-icon');
	var audioHTML = '<audio id="pronaudio" src=""></audio>';
		//var $pronaudio=$('#pronaudio');
		var pronaudio== new Audio;
	
function FindDic(word) {

	//alert('a');
var dictionaryOn = true;
	
	
	/* Queries web service through jQuery load 
		strips out all extraneous non-alpha character
		Also positions dictionary popup on opposite page based on the content-# of the words' parent element
	*/
	
		/* remove background from previous word before highlighting the next */
		
		
		var iframePos = $bookFrame.offset();
		var iframeWidth = $bookFrame.width();
		

		var xCoord = iframePos.left;
		var top = iframePos.top;

	
		var cssProp = {};
		
	
			cssProp = {
				'display' : 'block',
				'top' : '20%',
				'left' : '15%',
				'right' : ''
			}
		
		
		/*strip word of extraneous punctuation for web service */
	
		
		/*	make a call to dictionary webservice
			if return successful, load specified chunk of html ('.entry') into the dictionary popup block
			if return empty/non-successful, popuplate dictionary popup with 'word not found' text

			apply css properties to the popup, including the display: block property
		*/	
		$dictBody.load('/dictionary.ashx?word=' + encodeURIComponent(word) + ' .entry', function() {
			if($dictBody.text() == '') $dictBody.html('<div class="entry OD"><span class="hw">' + word + '</span><p>This word was not found in the dictionary</p></div>');
			$dictPopup.css(cssProp);
			$('.pron-icon').click();
		});
	
        }
		/*	handler for dictionary close button
		hide the dictionary pop-up, then remove the highlighting from the word
	*/
	$dictClose.click(function(e) {
		e.preventDefault();
		hideDictionary();
		if ($thisWord != null) $thisWord.css({ 'background-color' : ''});
	});
	
	/*	handler for dictionary pronunciation button
		play pronunciation in an <audio> element
	*/
	$dictBody.on('click', $('.pron-icon'),  function(e) {
		e.preventDefault();
		playPron($dictBody.find('.hw').text());
	});
	
	/*	play pronuciation audio in <audio> element
		strip out all punctuation to match audio filename
		change source of <audio> element to relevant word audio file
		load audio file into the <audio> (event handler will be called once audio is ready to be played)
	*/
	function playPron(word){
		word = removePunctuation(word);
		
		$pronaudio[0].src = '/dictionary/pronunciation/pron_' + word + '.mp3';
	
		$pronaudio[0].load();
		//alert('a');
	}

	/*	HTML5 Audio event handler
		Audio can be played, it has been downloaded and can start 
	*/
	$pronaudio[0].addEventListener("loaded", function () {
        //alert('b');
		this.play();
	}, false);
	
	/* Hide dictionary */
	function hideDictionary() {
		$dictPopup.css ({ 'display' : 'none'});
	}

	function removePunctuation(word) {
		return word.replace(/[\.,-\/#!$%\^&\*;:{}=\-_`~()]/g,"");
	}
};